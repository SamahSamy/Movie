package com.example.ppularmovie.Models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class responses {
    public List<Movie> movies() {
        return movies;
    }


    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }

    @SerializedName("resultes")
    private List<Movie> movies;

    private String page;

    private String total_pages;

    private String total_results;

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    public String getTotal_pages() {
        return total_pages;
    }

    public void setTotal_pages(String total_pages) {
        this.total_pages = total_pages;
    }

    public String getTotal_results() {
        return total_results;
    }

    public void setTotal_results(String total_results) {
        this.total_results = total_results;
    }
}
