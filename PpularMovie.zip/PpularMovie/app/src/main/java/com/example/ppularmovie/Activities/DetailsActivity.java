package com.example.ppularmovie.Activities;

import android.provider.SyncStateContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ppularmovie.Models.Movie;
import com.example.ppularmovie.R;
import com.example.ppularmovie.Util.constant;
import com.squareup.picasso.Picasso;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DetailsActivity extends AppCompatActivity {

    @BindView(R.id.mov_cover)
    ImageView movCover;
    @BindView(R.id.mov_poster)
    ImageView movPoster;
    @BindView(R.id.mov_Titel)
    TextView movTitel;
    @BindView(R.id.mov_Rate)
    TextView movRate;
    @BindView(R.id.mov_Date)
    TextView movDate;
    @BindView(R.id.movdescription)
    TextView movDescribe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        ButterKnife.bind(this);
        Bundle mBundle = getIntent().getExtras();


        int cover = mBundle.getInt(constant.Extra.COVER);
        int poster = mBundle.getInt(constant.Extra.POSTER);
        String title = getIntent().getParcelableExtra(constant.Extra.TITLE);
        String rate = getIntent().getParcelableExtra(constant.Extra.RATE);
        String date = getIntent().getParcelableExtra(constant.Extra.DATE);
        String describe = getIntent().getParcelableExtra(constant.Extra.DESCRIPTION);


        if (mBundle != null) {
            Movie movie = mBundle.getParcelable("movie");
            movTitel.setText(movie.getTitle());
            movDate.setText(movie.getRelease_date());
            movRate.setText(movie.getVote_average());
            movDescribe.setText(movie.getOverview());

        }

        Picasso.with(this)
                .load(constant.BASE_IMG_URL + cover)
                .into(movCover);
        Picasso.with(this)
                .load(constant.BASE_IMG_URL + poster)
                .into(movPoster);
        movTitel.setText(title);
        movRate.setText(rate);
        movDate.setText(date);
        movDescribe.setText(describe);


    }
}
