package com.example.ppularmovie.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.ParsedRequestListener;
import com.example.ppularmovie.Adapters.TrailerAdapter;
import com.example.ppularmovie.Models.TrailerRespond;
import com.example.ppularmovie.Util.constant;
import com.example.ppularmovie.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class Tralir extends AppCompatActivity {

    @BindView(R.id.trailerlist)
    RecyclerView recyclerView;
    private RecyclerView.LayoutManager mlayoutManager;
    private TrailerAdapter trailerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tralir);

        ButterKnife.bind(this);
        init();
        String movie_id = null;
        AndroidNetworking.get(constant.BASE_URL + "{movie_id}" + constant.VIDEOS)
                .addPathParameter("{movie_id", movie_id)
                .addQueryParameter(constant.API_key, constant.API_VAL)
                .build()
                .getAsObject(TrailerRespond.class, new ParsedRequestListener<TrailerRespond>() {


            @Override
            public void onResponse(TrailerRespond response) {

            }

            @Override
            public void onError(ANError anError) {

            }
        });

    }

    private void init() {
        mlayoutManager = new LinearLayoutManager(this);
    }
}
