package com.example.ppularmovie.Models;

import com.example.ppularmovie.Models.Trailer;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TrailerRespond {
    @SerializedName("id")
    private int id;
    @SerializedName("results")
    List<Trailer> trailers;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Trailer> getTrailers() {
        return trailers;
    }

    public void setTrailers(List<Trailer> trailers) {
        this.trailers = trailers;
    }
}
