package com.example.ppularmovie.Adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.ppularmovie.Activities.DetailsActivity;
import com.example.ppularmovie.Models.Movie;
import com.example.ppularmovie.R;
import com.example.ppularmovie.Util.constant;
import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MovAdapter extends RecyclerView.Adapter<MovAdapter.MovHolder> {

    private Context context;
    private List<Movie> items;

    public MovAdapter(Context context, List<Movie> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public MovHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.movies, viewGroup, false);
        MovHolder movHolder = new MovHolder(view);
        return movHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MovHolder movHolder, int i) {

        final Movie movie = items.get(i);
        movHolder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra("movie_object", (Parcelable) movie);
                intent.putExtra(constant.Extra.POSTER, movie.getBackdrop_path());
                intent.putExtra(constant.Extra.TITLE, movie.getTitle());
                intent.putExtra(constant.Extra.RATE, movie.getVote_average());
                intent.putExtra(constant.Extra.DATE, movie.getRelease_date());
                intent.putExtra(constant.Extra.DESCRIPTION, movie.getOverview());
                context.startActivity(intent);

            }
        });
        Picasso.with(context)
                .load(constant.BASE_IMG_URL + movie.getPoster_path())
                .placeholder(R.drawable.ss)
                .into(movHolder.imageView);

    }


    @Override
    public int getItemCount() {

        if (items != null) return items.size();
        return 0;


    }


    public class MovHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.CardMove)
        CardView cardView;
        @BindView(R.id.imgCardMove)
        ImageView imageView;

        public MovHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}

