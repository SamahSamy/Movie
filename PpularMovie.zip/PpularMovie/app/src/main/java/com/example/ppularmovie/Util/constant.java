package com.example.ppularmovie.Util;

import com.androidnetworking.BuildConfig;

public interface constant {

    String BASE_URL="https://api.themoviedb.org/3/movie/";
    String API_key="api_key";
    String API_VAL = "3c628f0f60f6786d07822d11ece90244";


    String TOP_MOVIES_KEY = "popular";
    String TOP_RATED_MOVIES_KEY = "top_rated";
    String BASE_IMG_URL = "https://image.tmdb.org/t/p/w500";
    String VIDEOS = "/videos";

    interface Extra {
        String COVER = "cover";
        String POSTER = "pster";
        String TITLE = "title";
        String RATE = "rate";
        String DATE = "date";
        String DESCRIPTION = "description";

    }
}
